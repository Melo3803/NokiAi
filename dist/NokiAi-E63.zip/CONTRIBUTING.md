# Contributing

Run `build.ps1` followed by `test.ps1` before submitting changes. Tests need
a JDK, Node.js, Python and Pillow from `requirements-dev.txt`.

Keep the app compatible with CLDC 1.1, MIDP 2.0 and Java 1.3 source syntax.
Avoid Java SE APIs such as `java.net`, generics and `StringBuilder`.
Keep the direct phone-to-Google connection.

Use synthetic API keys and mock HTTPS in tests. Never commit real keys,
key QR images, private conversations or personal recordings.

When reporting bugs, include the phone model, app version, steps to reproduce
and the error message with private information removed. State whether a feature
was tested on a physical phone or only in an emulator.

Build caches and `dist/` are ignored by Git. Installation files can be attached
to GitHub Releases. Use `python tools/package_project.py` to create a source ZIP.
