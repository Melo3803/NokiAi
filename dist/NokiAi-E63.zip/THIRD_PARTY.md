# Third-party notices

The project's own source code uses the MIT license in `LICENSE`.
These dependencies retain their own licenses:

| Component | Use | License |
| --- | --- | --- |
| [ZXing Core 1.7](https://github.com/zxing/zxing) | QR decoding on the phone; selected sources are recompiled for CLDC | Apache-2.0; see `resources/NOTICE.txt` and `resources/licenses/Apache-2.0.txt` |
| [qrcode-generator 1.4.4](https://github.com/kazuhikoarase/qrcode-generator) | Offline HTML key QR generator | MIT; copyright and license are included in the helper |

Build and test tools are downloaded separately and are not included in the source ZIP:
Eclipse ECJ 4.6.1, ProGuard 6.2.2, MicroEmulator 2.0.4 and its API libraries.
Download URLs and SHA-256 checksums are in `build.ps1` and `test.ps1`.
Their runtime implementations are not bundled in the phone app.

Phone TLS patches are separate projects and are not distributed in this package.
